package es.joseluisgs.dam.events;

// Es la interfaz que implementan los listeners de nuestro programa.
// que estén interesados en el evento "Hello"
interface HelloListener {
    void someoneSaidHello();
}